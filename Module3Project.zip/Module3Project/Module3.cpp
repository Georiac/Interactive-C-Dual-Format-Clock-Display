#include <iostream>
#include <string>
#include <cstring>

using namespace std;

// A clock class to represent the time
class Clock {
private:
    unsigned int hour;
    unsigned int minute;
    unsigned int second;

public:
    // A constructor to initialize the time
    Clock(unsigned int h = 0, unsigned int m = 0, unsigned int s = 0) : hour(h), minute(m), second(s) {}

    // Getter functions for the hour, minute, and second
    unsigned int getHour() const {
        return hour;
    }

    unsigned int getMinute() const {
        return minute;
    }

    unsigned int getSecond() const {
        return second;
    }

    // Setter functions for hour, minute, and second
    void setHour(unsigned int h) {
        hour = h;
    }

    void setMinute(unsigned int m) {
        minute = m;
    }

    void setSecond(unsigned int s) {
        second = s;
    }

    // Utility functions
    string twoDigitString(unsigned int n) const {
        if (n < 10) {
            return "0" + to_string(n);
        }
        else {
            return to_string(n);
        }
    }

    string nCharString(size_t n, char c) const { // Function for outputting any character at any length
        return string(n, c);
    }

    string formatTime24() const { // Function for the 24-hour clock format
        string hourFormatted = twoDigitString(hour);
        string minuteFormatted = twoDigitString(minute);
        string secondFormatted = twoDigitString(second);

        string timeFormatted = hourFormatted + ":" + minuteFormatted + ":" + secondFormatted;

        return timeFormatted;
    }

    string formatTime12() const { // Function for converting 24-hour format to a 12-hour clock format and checks if time requires A M or P M
        string ampmFormat;
        ampmFormat = "A M";
        if (hour < 12) {
            ampmFormat = "A M";
        }
        else {
            ampmFormat = "P M";
        }

        unsigned int h = (hour % 12 == 0) ? 12 : hour % 12;

        string result = twoDigitString(h) + ":" + twoDigitString(minute) + ":" + twoDigitString(second) + " " + ampmFormat;
        return (result);
    }

    void printMenu(const char* strings[], unsigned int numStrings, unsigned char width) const { // Function for the design of the menu
        cout << nCharString(width, '*') << endl;
        for (int i = 0; i < numStrings; ++i) {
            int num_ofSpaces = width - 7 - strlen(strings[i]);
            cout << '*' << ' ' << i + 1 << " - " << strings[i] << nCharString(num_ofSpaces, ' ') << '*' << endl;
            if (i < numStrings - 1) {
                cout << endl;
            }
        }
        cout << nCharString(width, '*') << endl;
    }

    unsigned int getMenuChoice(unsigned int maxChoice) const { // A function that checks if user enters a choice that is not in range of the 4 choices, if it's not in range, it will prompt for user input again
        unsigned int inputChoice;

        do {
            cout << "Enter your choice: ";
            cin >> inputChoice;
        } while (inputChoice < 1 || inputChoice > maxChoice);
        return inputChoice;
    }

    void displayClocks() const { // This is a void function that will display the design of the two clocks simultaneously
        cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
        cout << nCharString(1, '*') << nCharString(6, ' ') << "12-HOUR CLOCK" << nCharString(6, ' ') << nCharString(1, '*') << nCharString(3, ' ');
        cout << nCharString(1, '*') << nCharString(6, ' ') << "24-HOUR CLOCK" << nCharString(6, ' ') << nCharString(1, '*') << endl;
        cout << endl;
        cout << nCharString(1, '*') << nCharString(6, ' ') << formatTime12() << nCharString(7, ' ') << nCharString(1, '*') << nCharString(3, ' ');
        cout << nCharString(1, '*') << nCharString(8, ' ') << formatTime24() << nCharString(9, ' ') << nCharString(1, '*') << endl;
        cout << nCharString(27, '*') << nCharString(3, ' ') << nCharString(27, '*') << endl;
    }

    /**
     * A void function that adds one second
     */
    void addOneSecond() {
        if (second < 59) {
            second++;
        }
        else {
            second = 0;
            addOneMinute();
        }
    }

    /**
     * A void function that adds one minute
     */
    void addOneMinute() {
        if (minute < 59) {
            minute++;
        }
        else {
            minute = 0;
            addOneHour();
        }
    }

    /**
     * A void function that adds one hour
     */
    void addOneHour() {
        hour = (hour + 1) % 24;
    }

    void mainMenu() { // Main menu function to represent the options on the menu
        int userChoice;
        do {
            const char* menuOptions[] = { "Add One Hour", "Add One Minute", "Add One Second", "Exit" }; // A list of options for the user
            printMenu(menuOptions, 4, 27);
            displayClocks();
            userChoice = getMenuChoice(4);
            switch (userChoice) { // A switch statement for when an option is picked by the user
            case 1:
                addOneHour();
                break;
            case 2:
                addOneMinute();
                break;
            case 3:
                addOneSecond();
                break;
            case 4:
                cout << "Exiting program." << endl;
                break;
            }
        } while (userChoice != 4);
    }
};

int main() {
    Clock myClock(11, 59, 55); // This is a clock object, you can set the initial time here.
    myClock.mainMenu();
    return 0;
}